package com.example.chronometrojd;

import android.app.Activity;
import android.widget.Button;
import android.widget.Chronometer;

import androidx.appcompat.app.AppCompatActivity;

public class inicio extends AppCompatActivity {
    Button btn_star,btn_stop,btn_set;
    Chronometer chronometer;

}
